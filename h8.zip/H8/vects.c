
extern void start(void);

void INT_Manual_Reset(void)
{
}

const void *HardwareVectors[] __attribute__ ((section (".vects"))) =
{
//;<<VECTOR DATA START (POWER ON RESET)>>
//;0 Power On Reset PC
start,
//;<<VECTOR DATA END (POWER ON RESET)>>
//vector 1 manual reset
//;<<VECTOR DATA START (MANUAL RESET)>>
//;2 Manual Reset PC
INT_Manual_Reset,
//;<<VECTOR DATA END (MANUAL RESET)>>
};

